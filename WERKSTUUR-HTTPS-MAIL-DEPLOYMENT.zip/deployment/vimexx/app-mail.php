<?php
declare(strict_types=1);

// Server-to-server mail API. Its signing key stays outside public_html.
umask(0077);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function respond(int $code, array $data): never {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}
function save_state(string $path, array $data): bool {
    $json = json_encode($data, JSON_THROW_ON_ERROR);
    $temp = $path . '.tmp';
    return file_put_contents($temp, $json, LOCK_EX) === strlen($json) && rename($temp, $path);
}
function valid_email(mixed $value): string {
    if (!is_string($value) || strlen($value) > 254 || preg_match('/[\r\n]/', $value)) return '';
    return filter_var($value, FILTER_VALIDATE_EMAIL) ? $value : '';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    respond(405, ['ok' => false, 'error' => 'method_not_allowed']);
}
if (strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0])) !== 'application/json') {
    respond(415, ['ok' => false, 'error' => 'json_required']);
}
$raw = file_get_contents('php://input', false, null, 0, 220001);
if ($raw === false || strlen($raw) > 220000) respond(413, ['ok' => false, 'error' => 'too_large']);

$private = dirname(__DIR__) . '/app-mail-data';
$configPath = $private . '/config.php';
if (!is_file($configPath)) respond(503, ['ok' => false, 'error' => 'not_configured']);
$config = require $configPath;
$secret = $config['secret'] ?? '';
$from = valid_email($config['from'] ?? '');
if (!is_string($secret) || strlen($secret) < 32 || $from !== 'info@werkstuur.nl') {
    respond(503, ['ok' => false, 'error' => 'not_configured']);
}
$stamp = $_SERVER['HTTP_X_WERKSTUUR_TIMESTAMP'] ?? '';
$nonce = $_SERVER['HTTP_X_WERKSTUUR_NONCE'] ?? '';
$signature = $_SERVER['HTTP_X_WERKSTUUR_SIGNATURE'] ?? '';
if (!preg_match('/^\d{10}$/D', $stamp) || abs(time() - (int)$stamp) > 300 ||
    !preg_match('/^[a-f0-9]{32}$/D', $nonce) || !preg_match('/^[a-f0-9]{64}$/D', $signature)) {
    respond(401, ['ok' => false, 'error' => 'unauthorized']);
}
$bodyHash = hash('sha256', $raw);
$expected = hash_hmac('sha256', $stamp . "\n" . $nonce . "\n" . $bodyHash, $secret);
if (!hash_equals($expected, $signature)) respond(401, ['ok' => false, 'error' => 'unauthorized']);
try { $body = json_decode($raw, true, 12, JSON_THROW_ON_ERROR); }
catch (JsonException $e) { respond(400, ['ok' => false, 'error' => 'invalid_json']); }
if (!is_array($body) || !is_array($body['recipients'] ?? null) ||
    count($body['recipients']) < 1 || count($body['recipients']) > 10) {
    respond(400, ['ok' => false, 'error' => 'invalid_recipients']);
}
$recipients = [];
foreach ($body['recipients'] as $recipient) {
    $address = valid_email($recipient);
    if ($address === '') respond(400, ['ok' => false, 'error' => 'invalid_recipient']);
    $recipients[strtolower($address)] = $address;
}
$to = implode(', ', array_values($recipients));
$subject = $body['subject'] ?? '';
$text = $body['text'] ?? '';
$html = $body['html'] ?? '';
$replyTo = $body['reply_to'] ?? '';
if (!is_string($subject) || $subject === '' || strlen($subject) > 512 || preg_match('/[\r\n]/', $subject) ||
    strlen($to) > 900 || !is_string($text) || strlen($text) > 120000 ||
    !is_string($html) || strlen($html) > 120000 || !is_string($replyTo) ||
    ($replyTo !== '' && valid_email($replyTo) === '')) {
    respond(400, ['ok' => false, 'error' => 'invalid_message']);
}

// Keep only delivery metadata, never password links or message contents.
$messages = $private . '/messages';
$rates = $private . '/rates';
foreach ([$messages, $rates] as $directory) {
    if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
        respond(503, ['ok' => false, 'error' => 'storage_unavailable']);
    }
}
$lock = fopen($messages . '/' . $nonce . '.lock', 'c');
if (!$lock || !flock($lock, LOCK_EX)) respond(503, ['ok' => false, 'error' => 'storage_unavailable']);
$statePath = $messages . '/' . $nonce . '.json';
$state = is_file($statePath) ? json_decode((string)file_get_contents($statePath), true) : null;
if (is_array($state)) {
    if (($state['body_hash'] ?? '') !== $bodyHash) respond(409, ['ok' => false, 'error' => 'nonce_conflict']);
    if (($state['status'] ?? '') === 'sent') {
        respond(200, ['ok' => true, 'id' => $nonce, 'recipients' => count($recipients), 'duplicate' => true]);
    }
    // An interrupted send has an unknown delivery outcome. Do not send it twice.
    if (($state['status'] ?? '') === 'pending') respond(503, ['ok' => false, 'error' => 'delivery_uncertain']);
    if (($state['attempts'] ?? 0) >= 3) respond(503, ['ok' => false, 'error' => 'delivery_failed']);
}
$ratePath = $rates . '/' . gmdate('Ymd-H') . '.json';
$rateLock = fopen($ratePath . '.lock', 'c');
if (!$rateLock || !flock($rateLock, LOCK_EX)) respond(503, ['ok' => false, 'error' => 'storage_unavailable']);
$rate = is_file($ratePath) ? json_decode((string)file_get_contents($ratePath), true) : [];
$count = (int)($rate['count'] ?? 0);
if ($count >= 200) {
    header('Retry-After: 3600');
    respond(429, ['ok' => false, 'error' => 'rate_limited']);
}
if (!save_state($ratePath, ['count' => $count + 1])) respond(503, ['ok' => false, 'error' => 'storage_unavailable']);
flock($rateLock, LOCK_UN);
fclose($rateLock);
$state = ['body_hash' => $bodyHash, 'status' => 'pending',
          'attempts' => (int)($state['attempts'] ?? 0) + 1,
          'recipient_hash' => hash('sha256', strtolower($to)), 'at' => time()];
if (!save_state($statePath, $state)) respond(503, ['ok' => false, 'error' => 'storage_unavailable']);

$headers = ['From: Werkstuur <info@werkstuur.nl>', 'MIME-Version: 1.0',
            'Message-ID: <' . $nonce . '@werkstuur.nl>'];
if ($replyTo !== '') $headers[] = 'Reply-To: ' . $replyTo;
if ($html !== '') {
    $boundary = 'ws_' . bin2hex(random_bytes(12));
    $headers[] = 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';
    $message = '--' . $boundary . "\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" .
        chunk_split(base64_encode($text), 76, "\r\n") . '--' . $boundary .
        "\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" .
        chunk_split(base64_encode($html), 76, "\r\n") . '--' . $boundary . "--\r\n";
} else {
    $headers[] = 'Content-Type: text/plain; charset=UTF-8';
    $headers[] = 'Content-Transfer-Encoding: base64';
    $message = chunk_split(base64_encode($text), 76, "\r\n");
}
$encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
$ok = mail($to, $encodedSubject, $message, implode("\r\n", $headers), '-finfo@werkstuur.nl');
$state['status'] = $ok ? 'sent' : 'failed';
$state['at'] = time();
if (!save_state($statePath, $state)) respond(503, ['ok' => false, 'error' => 'delivery_uncertain']);
respond($ok ? 200 : 503, $ok ? ['ok' => true, 'id' => $nonce, 'recipients' => count($recipients)] :
    ['ok' => false, 'error' => 'delivery_failed']);
