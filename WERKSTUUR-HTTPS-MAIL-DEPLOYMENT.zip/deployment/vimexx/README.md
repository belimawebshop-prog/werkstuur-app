# Werkstuur HTTPS-mail via bestaande Vimexx-hosting

Deze route houdt Render Free bruikbaar zonder SMTP of extra abonnementen.
De oorspronkelijke app.werkstuur.nl-service blijft behouden.

## Bestanden

- Plaats `app-mail.php` in `/domains/werkstuur.nl/public_html/`, rechten 644.
- De configuratie hoort in `/domains/werkstuur.nl/app-mail-data/config.php`,
  buiten public_html. Maprechten 700, bestandsrechten 600, eigenaar dezelfde
  hostinggebruiker als de website. Gebruik `config.example.php` als sjabloon.
- Zet de geheime signing key uitsluitend in de private PHP-configuratie en in
  de servervariabele `WEBMAIL_RELAY_SECRET` van de Werkstuur-service.
- Bewaar geen sleutel in Git, openbare bestanden, Render Secret Files of logs.
- De app gebruikt `MAIL_TRANSPORT=https`,
  `WEBMAIL_RELAY_URL=https://werkstuur.nl/app-mail.php`,
  `SMTP_FROM_EMAIL=info@werkstuur.nl`, `SMTP_REPLY_TO=support@werkstuur.nl`.
- Gebruik de bestaande Supabase-URL, serverkey en private opslagbucket.
  Geen databasewijziging of bootstrapwachtwoord is nodig voor de appkopie.

## Beveiliging en controle

Het endpoint vereist een HMAC-handtekening, een timestamp van maximaal vijf
minuten oud en een unieke nonce. Herhaling van dezelfde nonce en inhoud geeft
een ontvangstbevestiging zonder tweede verzending. Andere inhoud met dezelfde
nonce wordt geweigerd. Maximaal 200 mailpogingen per uur. Alleen metadata blijft
bewaard; berichtinhoud en wachtwoordlinks worden niet opgeslagen.

Controleer een eigen testmail, een dubbele aanvraag, foutieve handtekeningen en
headerinjectie. GET hoort 405 en een ongetekende POST 401 te geven.
Controleer na uitrol ook `/api/health` en verzending vanuit de Render-app.

Render Free kan na inactiviteit slapen; de eerste aanvraag kan daardoor langer
duren. Er is geen betaalde server of extra opslagdisk nodig. Bewaar backups en
de oorspronkelijke service voordat je bestanden vervangt. Verwijder metadata
alleen volgens een afzonderlijk afgesproken bewaarbeleid; deze versie ruimt
niets automatisch op.
