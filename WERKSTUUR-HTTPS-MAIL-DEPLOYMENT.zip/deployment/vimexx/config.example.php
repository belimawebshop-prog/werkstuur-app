<?php
// Keep the real file in /domains/werkstuur.nl/app-mail-data/config.php (0600).
// The containing directory must be 0700, outside public_html.
return ['secret' => 'SET_A_SERVER_ONLY_RANDOM_SECRET', 'from' => 'info@werkstuur.nl'];
